
#![allow(dead_code, unused_imports, clippy::all)]

use mlua::{FromLua, IntoLua, Lua, Value};

use super::convert::*;
use super::gen_client::LuaEntityRef;


pub struct LuaDirection(pub azalea::core::hit_result::Direction);

impl FromLua for LuaDirection {
    fn from_lua(value: Value, lua: &Lua) -> mlua::Result<Self> {
        let s = <String as FromLua>::from_lua(value, lua)?;
        Ok(Self(match s.as_str() {
            "down" => azalea::core::hit_result::Direction::Down,
            "up" => azalea::core::hit_result::Direction::Up,
            "north" => azalea::core::hit_result::Direction::North,
            "south" => azalea::core::hit_result::Direction::South,
            "west" => azalea::core::hit_result::Direction::West,
            "east" => azalea::core::hit_result::Direction::East,
            other => return Err(mlua::Error::runtime(format!("invalid Direction '{other}', expected one of: down, up, north, south, west, east"))),
        }))
    }
}

impl IntoLua for LuaDirection {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let s: &str = match self.0 {
            azalea::core::hit_result::Direction::Down => "down",
            azalea::core::hit_result::Direction::Up => "up",
            azalea::core::hit_result::Direction::North => "north",
            azalea::core::hit_result::Direction::South => "south",
            azalea::core::hit_result::Direction::West => "west",
            azalea::core::hit_result::Direction::East => "east",
            #[allow(unreachable_patterns)]
            _ => "unknown",
        };
        Ok(Value::String(lua.create_string(s)?))
    }
}


pub struct LuaWalkDirection(pub azalea::WalkDirection);

impl FromLua for LuaWalkDirection {
    fn from_lua(value: Value, lua: &Lua) -> mlua::Result<Self> {
        let s = <String as FromLua>::from_lua(value, lua)?;
        Ok(Self(match s.as_str() {
            "none" => azalea::WalkDirection::None,
            "forward" => azalea::WalkDirection::Forward,
            "backward" => azalea::WalkDirection::Backward,
            other => return Err(mlua::Error::runtime(format!("invalid WalkDirection '{other}', expected one of: none, forward, backward"))),
        }))
    }
}

impl IntoLua for LuaWalkDirection {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let s: &str = match self.0 {
            azalea::WalkDirection::None => "none",
            azalea::WalkDirection::Forward => "forward",
            azalea::WalkDirection::Backward => "backward",
            #[allow(unreachable_patterns)]
            _ => "unknown",
        };
        Ok(Value::String(lua.create_string(s)?))
    }
}


pub struct LuaAttributeInstance(pub azalea::AttributeInstance);

impl IntoLua for LuaAttributeInstance {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("base", v.base)?;
        t.set("value", v.calculate())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaAttributes(pub azalea::Attributes);

impl IntoLua for LuaAttributes {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("movement_speed", LuaAttributeInstance(v.movement_speed))?;
        t.set("sneaking_speed", LuaAttributeInstance(v.sneaking_speed))?;
        t.set("attack_speed", LuaAttributeInstance(v.attack_speed))?;
        t.set("water_movement_efficiency", LuaAttributeInstance(v.water_movement_efficiency))?;
        t.set("mining_efficiency", LuaAttributeInstance(v.mining_efficiency))?;
        t.set("block_break_speed", LuaAttributeInstance(v.block_break_speed))?;
        t.set("block_interaction_range", LuaAttributeInstance(v.block_interaction_range))?;
        t.set("entity_interaction_range", LuaAttributeInstance(v.entity_interaction_range))?;
        t.set("step_height", LuaAttributeInstance(v.step_height))?;
        Ok(Value::Table(t))
    }
}


pub struct LuaBlockHitResult(pub azalea::core::hit_result::BlockHitResult);

impl IntoLua for LuaBlockHitResult {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("location", LVec3(v.location))?;
        t.set("miss", v.miss)?;
        t.set("direction", LuaDirection(v.direction))?;
        t.set("block_pos", LBlockPos(v.block_pos))?;
        t.set("inside", v.inside)?;
        t.set("world_border", v.world_border)?;
        Ok(Value::Table(t))
    }
}


pub struct LuaChatPacket(pub azalea::ChatPacket);

impl IntoLua for LuaChatPacket {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("message", v.message().to_string())?;
        t.set("sender", v.sender())?;
        t.set("content", v.content())?;
        t.set("is_whisper", v.is_whisper())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaClientboundPlayerCombatKill(pub azalea::protocol::packets::game::ClientboundPlayerCombatKill);

impl IntoLua for LuaClientboundPlayerCombatKill {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("player_id", LMinecraftEntityId(v.player_id))?;
        t.set("message", v.message.to_string())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaEntityHitResult(pub azalea::core::hit_result::EntityHitResult, pub azalea::Client);

impl IntoLua for LuaEntityHitResult {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let (v, client) = (self.0, self.1);
        let t = lua.create_table()?;
        t.set("location", LVec3(v.location))?;
        t.set("entity", LuaEntityRef { entity: client.entity_ref_for(v.entity) })?;
        Ok(Value::Table(t))
    }
}


pub struct LuaExperience(pub azalea::Experience);

impl IntoLua for LuaExperience {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("progress", v.progress)?;
        t.set("level", v.level)?;
        t.set("total", v.total)?;
        Ok(Value::Table(t))
    }
}


pub struct LuaGameProfile(pub azalea::GameProfile);

impl IntoLua for LuaGameProfile {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("uuid", v.uuid.to_string())?;
        t.set("name", v.name)?;
        Ok(Value::Table(t))
    }
}


pub struct LuaLookDirection(pub azalea::LookDirection);

impl IntoLua for LuaLookDirection {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("y_rot", v.y_rot())?;
        t.set("x_rot", v.x_rot())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaPhysics(pub azalea::Physics);

impl IntoLua for LuaPhysics {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("velocity", LVec3(v.velocity))?;
        t.set("horizontal_collision", v.horizontal_collision)?;
        t.set("vertical_collision", v.vertical_collision)?;
        t.set("was_touching_water", v.was_touching_water)?;
        t.set("fall_distance", v.fall_distance)?;
        t.set("remaining_fire_ticks", v.remaining_fire_ticks)?;
        t.set("on_ground", v.on_ground())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaPlayerInfo(pub azalea::PlayerInfo);

impl IntoLua for LuaPlayerInfo {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let v = self.0;
        let t = lua.create_table()?;
        t.set("name", v.profile.name.clone())?;
        t.set("uuid", v.uuid.to_string())?;
        t.set("latency", v.latency)?;
        t.set("gamemode", format!("{:?}", v.gamemode).to_lowercase())?;
        Ok(Value::Table(t))
    }
}


pub struct LuaHitResult(pub azalea::core::hit_result::HitResult, pub azalea::Client);

impl IntoLua for LuaHitResult {
    fn into_lua(self, lua: &Lua) -> mlua::Result<Value> {
        let client = self.1;
        let t = lua.create_table()?;
        match self.0 {
            azalea::core::hit_result::HitResult::Block(v) => {
                t.set("kind", "block")?;
                t.set("location", LVec3(v.location))?;
                t.set("miss", v.miss)?;
                t.set("direction", LuaDirection(v.direction))?;
                t.set("block_pos", LBlockPos(v.block_pos))?;
                t.set("inside", v.inside)?;
                t.set("world_border", v.world_border)?;
            }
            azalea::core::hit_result::HitResult::Entity(v) => {
                t.set("kind", "entity")?;
                t.set("location", LVec3(v.location))?;
                t.set("entity", LuaEntityRef { entity: client.entity_ref_for(v.entity) })?;
            }
            #[allow(unreachable_patterns)]
            _ => {}
        }
        Ok(Value::Table(t))
    }
}

