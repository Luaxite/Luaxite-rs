
#![allow(dead_code, unused_imports, clippy::all)]

use std::sync::Arc;

use azalea::prelude::*;
use mlua::UserData;

use super::convert::*;
use super::gen_events::EVENT_NAMES;
use super::gen_types::*;
use super::Handlers;
use azalea::pathfinder::PathfinderClientExt as _;


#[derive(UserData)]
pub struct LuaClient {
    #[lua(skip)]
    pub client: azalea::Client,
    #[lua(skip)]
    pub handlers: Arc<Handlers>,
}

#[mlua::userdata_impl]
impl LuaClient {
    
    fn on(&self, event: String, handler: mlua::Function) -> mlua::Result<()> {
        if !EVENT_NAMES.contains(&event.as_str()) {
            return Err(mlua::Error::runtime(format!("unknown event '{event}' (known: {})", EVENT_NAMES.join(", "))));
        }
        self.handlers.add(event, handler);
        Ok(())
    }

    
    async fn wait_for(&self, event: String) -> mlua::Result<mlua::MultiValue> {
        if !EVENT_NAMES.contains(&event.as_str()) {
            return Err(mlua::Error::runtime(format!("unknown event '{event}' (known: {})", EVENT_NAMES.join(", "))));
        }
        self.handlers.wait(&event).await
    }

    #[lua(infallible)]
    fn attack(&self, entity: mlua::UserDataRef<LuaEntityRef>) {
        self.client.attack(entity.entity.id())
    }

    fn attributes(&self) -> mlua::Result<LuaAttributes> {
        self.client.attributes().map_err(lua_err).map(|v| LuaAttributes(v))
    }

    fn broken(&self) -> mlua::Result<f32> {
        self.client.broken().map_err(lua_err)
    }

    #[lua(infallible)]
    fn chat(&self, content: String) {
        self.client.chat(content)
    }

    fn direction(&self) -> mlua::Result<LuaLookDirection> {
        self.client.direction().map_err(lua_err).map(|v| LuaLookDirection(v))
    }

    #[lua(infallible)]
    fn entity(&self) -> LuaEntityRef {
        LuaEntityRef { entity: self.client.entity() }
    }

    fn entity_by_minecraft_id(&self, id: LMinecraftEntityId) -> mlua::Result<Option<LuaEntityRef>> {
        self.client.entity_by_minecraft_id(id.0).map_err(lua_err).map(|v| v.map(|v| LuaEntityRef { entity: v }))
    }

    fn entity_by_uuid(&self, uuid: String) -> mlua::Result<Option<LuaEntityRef>> {
        Ok(self.client.entity_by_uuid(uuid.parse().map_err(lua_err)?).map(|v| LuaEntityRef { entity: v }))
    }

    fn entity_id_by_minecraft_id(&self, id: LMinecraftEntityId) -> mlua::Result<Option<LuaEntityRef>> {
        self.client.entity_id_by_minecraft_id(id.0).map_err(lua_err).map(|v| v.map(|v| LuaEntityRef { entity: self.client.entity_ref_for(v) }))
    }

    fn entity_id_by_uuid(&self, uuid: String) -> mlua::Result<Option<LuaEntityRef>> {
        Ok(self.client.entity_id_by_uuid(uuid.parse().map_err(lua_err)?).map(|v| LuaEntityRef { entity: self.client.entity_ref_for(v) }))
    }

    #[lua(infallible)]
    fn entity_interact(&self, entity: mlua::UserDataRef<LuaEntityRef>) {
        self.client.entity_interact(entity.entity.id())
    }

    #[lua(infallible)]
    fn entity_ref_for(&self, entity: mlua::UserDataRef<LuaEntityRef>) -> LuaEntityRef {
        LuaEntityRef { entity: self.client.entity_ref_for(entity.entity.id()) }
    }

    fn experience(&self) -> mlua::Result<LuaExperience> {
        self.client.experience().map_err(lua_err).map(|v| LuaExperience(v))
    }

    fn get_held_item(&self) -> mlua::Result<LItem> {
        self.client.get_held_item().map_err(lua_err).map(|v| LItem(v))
    }

    fn get_inventory(&self) -> mlua::Result<LuaContainer> {
        self.client.get_inventory().map_err(lua_err).map(|v| LuaContainer { handle: Some(Held::Borrowed(v)) })
    }

    #[lua(infallible)]
    async fn goto(&self, pos: LBlockPos) {
        self.client.goto(azalea::pathfinder::goals::BlockPosGoal(pos.0)).await
    }

    #[lua(infallible)]
    async fn goto_with_opts(&self, pos: LBlockPos, opts: LPathfinderOpts) {
        self.client.goto_with_opts(azalea::pathfinder::goals::BlockPosGoal(pos.0), opts.0).await
    }

    #[lua(infallible)]
    async fn goto_with_opts_xz(&self, x: i32, z: i32, opts: LPathfinderOpts) {
        self.client.goto_with_opts(azalea::pathfinder::goals::XZGoal { x: x, z: z }, opts.0).await
    }

    #[lua(infallible)]
    async fn goto_xz(&self, x: i32, z: i32) {
        self.client.goto(azalea::pathfinder::goals::XZGoal { x: x, z: z }).await
    }

    fn health(&self) -> mlua::Result<f32> {
        self.client.health().map_err(lua_err)
    }

    fn hit_result(&self) -> mlua::Result<LuaHitResult> {
        self.client.hit_result().map_err(lua_err).map(|v| LuaHitResult(v, self.client.clone()))
    }

    #[lua(infallible)]
    fn look_at(&self, position: LVec3) {
        self.client.look_at(position.0)
    }

    fn menu(&self) -> mlua::Result<LMenu> {
        self.client.menu().map_err(lua_err).map(|v| LMenu(v))
    }

    #[lua(infallible)]
    async fn mine(&self, position: LBlockPos) {
        self.client.mine(position.0).await
    }

    async fn mine_with_auto_tool(&self, block_pos: LBlockPos) -> mlua::Result<()> {
        self.client.mine_with_auto_tool(block_pos.0).await.map_err(lua_err)
    }

    fn minecraft_id(&self) -> mlua::Result<LMinecraftEntityId> {
        self.client.minecraft_id().map_err(lua_err).map(|v| LMinecraftEntityId(v))
    }

    fn nearby_players(&self) -> mlua::Result<Vec<LuaEntityRef>> {
        self.client.nearby_players().map_err(lua_err).map(|v| Vec::from(v).into_iter().map(|v| LuaEntityRef { entity: v }).collect::<Vec<_>>())
    }

    async fn open_container_at(&self, pos: LBlockPos) -> mlua::Result<Option<LuaContainer>> {
        self.client.open_container_at(pos.0).await.map_err(lua_err).map(|v| v.map(|v| LuaContainer { handle: Some(Held::Owned(v)) }))
    }

    async fn open_container_at_with_timeout_ticks(&self, pos: LBlockPos, timeout_ticks: Option<usize>) -> mlua::Result<Option<LuaContainer>> {
        self.client.open_container_at_with_timeout_ticks(pos.0, timeout_ticks).await.map_err(lua_err).map(|v| v.map(|v| LuaContainer { handle: Some(Held::Owned(v)) }))
    }

    fn open_inventory(&self) -> mlua::Result<Option<LuaContainer>> {
        self.client.open_inventory().map_err(lua_err).map(|v| v.map(|v| LuaContainer { handle: Some(Held::Owned(v)) }))
    }

    fn physics(&self) -> mlua::Result<LuaPhysics> {
        self.client.physics().map_err(lua_err).map(|v| LuaPhysics(v))
    }

    fn position(&self) -> mlua::Result<LVec3> {
        self.client.position().map_err(lua_err).map(|v| LVec3(v))
    }

    fn profile(&self) -> mlua::Result<LuaGameProfile> {
        self.client.profile().map_err(lua_err).map(|v| LuaGameProfile(v))
    }

    #[lua(infallible)]
    fn set_direction(&self, y_rot: f32, x_rot: f32) {
        self.client.set_direction(y_rot, x_rot)
    }

    #[lua(infallible)]
    fn start_goto(&self, pos: LBlockPos) {
        self.client.start_goto(azalea::pathfinder::goals::BlockPosGoal(pos.0))
    }

    #[lua(infallible)]
    fn start_goto_with_opts(&self, pos: LBlockPos, opts: LPathfinderOpts) {
        self.client.start_goto_with_opts(azalea::pathfinder::goals::BlockPosGoal(pos.0), opts.0)
    }

    #[lua(infallible)]
    fn start_goto_with_opts_xz(&self, x: i32, z: i32, opts: LPathfinderOpts) {
        self.client.start_goto_with_opts(azalea::pathfinder::goals::XZGoal { x: x, z: z }, opts.0)
    }

    #[lua(infallible)]
    fn start_goto_xz(&self, x: i32, z: i32) {
        self.client.start_goto(azalea::pathfinder::goals::XZGoal { x: x, z: z })
    }

    #[lua(infallible)]
    fn stop_pathfinding(&self) {
        self.client.stop_pathfinding()
    }

    #[lua(infallible)]
    fn tab_names(&self) -> Vec<String> {
        self.client.tab_names()
    }

    #[lua(infallible)]
    fn test_all_entities(&self) -> Vec<LuaEntityRef> {
        self.client.test_all_entities().into_iter().map(|v| LuaEntityRef { entity: v }).collect::<Vec<_>>()
    }

    #[lua(infallible)]
    fn test_count_boxed(&self, list: Vec<mlua::UserDataRef<LuaEntityRef>>) -> usize {
        self.client.test_count_boxed(list.into_iter().map(|v| v.entity.clone()).collect::<Box<[_]>>())
    }

    #[lua(infallible)]
    fn test_count_entities(&self, first: mlua::UserDataRef<LuaEntityRef>, maybe: Option<mlua::UserDataRef<LuaEntityRef>>, rest: Vec<mlua::UserDataRef<LuaEntityRef>>) -> usize {
        self.client.test_count_entities(first.entity.clone(), maybe.map(|v| v.entity.clone()), rest.into_iter().map(|v| v.entity.clone()).collect::<Vec<_>>())
    }

    async fn wait_for_container_open(&self, timeout_ticks: Option<usize>) -> mlua::Result<Option<LuaContainer>> {
        self.client.wait_for_container_open(timeout_ticks).await.map_err(lua_err).map(|v| v.map(|v| LuaContainer { handle: Some(Held::Owned(v)) }))
    }

    #[lua(infallible)]
    async fn wait_ticks(&self, n: usize) {
        self.client.wait_ticks(n).await
    }

    #[lua(infallible)]
    fn walk(&self, direction: LuaWalkDirection) {
        self.client.walk(direction.0)
    }

    #[lua(infallible)]
    fn write_chat_packet(&self, message: String) {
        self.client.write_chat_packet(&message)
    }
}


#[derive(UserData)]
pub struct LuaEntityRef {
    #[lua(skip)]
    pub entity: azalea::EntityRef,
}

#[mlua::userdata_impl]
impl LuaEntityRef {
    #[lua(infallible)]
    fn attack(&self) {
        self.entity.attack()
    }

    fn attributes(&self) -> mlua::Result<LuaAttributes> {
        self.entity.attributes().map_err(lua_err).map(|v| LuaAttributes(v))
    }

    fn health(&self) -> mlua::Result<f32> {
        self.entity.health().map_err(lua_err)
    }

    fn minecraft_id(&self) -> mlua::Result<LMinecraftEntityId> {
        self.entity.minecraft_id().map_err(lua_err).map(|v| LMinecraftEntityId(v))
    }

    fn physics(&self) -> mlua::Result<LuaPhysics> {
        self.entity.physics().map_err(lua_err).map(|v| LuaPhysics(v))
    }

    fn position(&self) -> mlua::Result<LVec3> {
        self.entity.position().map_err(lua_err).map(|v| LVec3(v))
    }
}
